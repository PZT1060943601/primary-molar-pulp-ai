# Synthetic example dataset

This directory contains a synthetic/example dataset for running the public preprocessing, training, and evaluation code. Its class distribution matches the manuscript's independent test set: 267 label-0 images and 238 label-1 images, total 505 images.

Important limitations:
- These images are computer-generated phantom images.
- They are not real pediatric dental radiographs.
- They do not preserve clinical image texture, diagnostic features, or patient anatomy.
- They should be used only to verify code execution, file structure, labels, and metric calculation.

Directory structure:
- images/pulp_not_involved/: synthetic label 0 images
- images/pulp_involved/: synthetic label 1 images
- labels.csv: image path, binary label, split, and synthetic patient identifier
- metadata.csv: same metadata in a simple CSV format

Label definition used by the manuscript:
- 0 = pulp-not-involved, corresponding to teeth treated with fillings in the original clinical records
- 1 = pulp-involved, corresponding to teeth treated with pulpotomy or root canal therapy in the original clinical records

The original clinical radiographic dataset is not included because it consists of hospital radiographs from pediatric patients and cannot be deposited in an unrestricted public repository under the current ethics and institutional data-governance requirements.
