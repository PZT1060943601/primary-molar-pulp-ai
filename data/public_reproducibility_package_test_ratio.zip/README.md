# Public reproducibility package

This package is intended for public repository deposition alongside the manuscript code.

Contents:

- `synthetic_example_dataset/`
  - A small computer-generated example dataset that mimics the expected file structure and label format.
  - It is not a real clinical dataset and must not be used for diagnostic training or validation.

- `dataset_statistics/`
  - Aggregate, non-identifying statistics for the original study dataset.
  - Test-set confusion-matrix counts and model metrics.
  - Suggested manuscript wording for the data and code availability statement.

The original pediatric clinical radiographs are not included because unrestricted public sharing is not permitted by the current ethics and institutional data-governance requirements.
