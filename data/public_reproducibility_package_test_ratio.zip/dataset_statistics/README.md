# Dataset statistics and sharing statement

## What is included

This folder provides aggregate statistics for the manuscript dataset and test-set model outputs. It does not contain any original clinical radiographs.

Files:
- `dataset_summary.json`: machine-readable summary of the dataset and sharing restrictions.
- `dataset_statistics.xlsx`: class distribution, demographics, test-set confusion matrices, and model metrics.
- `data_availability_statement.txt`: manuscript-ready data and code availability wording.

## Dataset summary

- Source: Department of Stomatology, Beijing Children's Hospital
- Study period: 2023-2024
- Total radiographs/teeth: 2,523
- Label 0, pulp-not-involved: 1,291
- Label 1, pulp-involved: 1,232
- Train/validation/test sizes: 1,614 / 404 / 505
- Test-set label distribution: 267 label-0 images and 238 label-1 images
- Age, mean +/- SD: 6.08 +/- 1.51 years
- Sex distribution: 1,155 female and 1,368 male records

## Label definition

- 0 = pulp-not-involved, corresponding to teeth treated with fillings in the original clinical records.
- 1 = pulp-involved, corresponding to teeth treated with pulpotomy or root canal therapy in the original clinical records.

## Data sharing limitation

The original dataset consists of clinical radiographs from pediatric patients. Although direct identifiers were removed for analysis, unrestricted public deposition of the original images or a representative raw-image subset is not permitted under the current ethics approval and institutional data-governance requirements. A synthetic/example dataset is provided separately to allow users to test the code pipeline and data format.


